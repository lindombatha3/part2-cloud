﻿namespace KhumaloCrafts.Controllers
{
    public class ContactViewModel
    {
    }
}