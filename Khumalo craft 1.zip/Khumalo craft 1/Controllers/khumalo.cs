﻿using System.Linq;
using System.Web.Mvc;

public class ProductController : Controller
{
    private readonly KhumaloCraftsDbContext _context;

    public ProductController()
    {
        _context = new KhumaloCraftsDbContext();
    }

    public ActionResult Index()
    {
        var products = _context.Products.ToList();
        return View(products);
    }

    public ActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public ActionResult Create(Product product)
    {
        if (ModelState.IsValid)
        {
            _context.Products.Add(product);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        return View(product);
    }
}
