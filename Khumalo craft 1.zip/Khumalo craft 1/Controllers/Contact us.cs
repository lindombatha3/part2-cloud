﻿using Microsoft.AspNetCore.Mvc;

namespace KhumaloCrafts.Controllers
{
    public class ContactUsController : Controller
    {
        // GET: ContactUs
        public ActionResult Index()
        {
            return View();
        }

        // POST: ContactUs
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(ContactViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Here you can handle the contact form submission, like sending an email or storing the message in a database.
                // For demonstration purposes, let's assume we just display a thank you message.
                ViewBag.Message = "Thank you for contacting us! We will get back to you soon.";
                return View("Confirmation");
            }
            // If the model state is not valid, return to the contact form to display validation errors.
            return View(model);
        }
    }
}
