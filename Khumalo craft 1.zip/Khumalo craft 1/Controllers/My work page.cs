﻿using Microsoft.AspNetCore.Mvc;

namespace KhumaloCrafts.Controllers
{
    public class MyWorkController : Controller
    {
        // GET: MyWork
        public ActionResult Index()
        {
            // Here you can retrieve data about your work to display on the My Work page
            // For demonstration purposes, let's assume we have a list of work items
            var workItems = GetWorkItems(); // You need to implement this method to get your work items
            return View(workItems);
        }

        private List<WorkItem> GetWorkItems()
        {
            // Implement this method to retrieve your work items from your data source
            // For demonstration purposes, let's just return a hardcoded list of work items
            var workItems = new List<WorkItem>
            {
                new WorkItem { Id = 1, Title = "Example Work 1", Description = "Description of example work 1" },
                new WorkItem { Id = 2, Title = "Example Work 2", Description = "Description of example work 2" },
                // Add more work items as needed
            };
            return workItems;
        }
    }

    public class WorkItem
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        // Add more properties as needed
    }
}
