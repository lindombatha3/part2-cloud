﻿namespace KhumaloCrafts.Models
{
    public class WorkItemModel
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        // You can add more properties here as needed to represent your work items, such as images, categories, etc.
    }
}
