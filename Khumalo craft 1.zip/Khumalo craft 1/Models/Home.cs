﻿namespace KhumaloCrafts.Models
{
    public class Home
    {
        // You can add properties here if you have any specific data to pass to the Home view
        // For example, if you want to display a welcome message or any other dynamic content
        public string WelcomeMessage { get; set; }
        // Add more properties as needed
    }
}
