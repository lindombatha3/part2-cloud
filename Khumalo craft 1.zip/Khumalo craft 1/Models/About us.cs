﻿namespace KhumaloCrafts.Models
{
    public class AboutUs
    {
        public string Mission { get; set; }
        public string Vision { get; set; }
        public string History { get; set; }
        // Add more properties as needed to represent information about your company
    }
}
