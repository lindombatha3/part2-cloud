﻿using System.ComponentModel.DataAnnotations;

namespace KhumaloCrafts.Models
{
    public class ContactUs
    {
        [Required(ErrorMessage = "Please enter your name")]
        [StringLength(100, ErrorMessage = "Name must not exceed 100 characters")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please enter your email address")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter a subject")]
        [StringLength(100, ErrorMessage = "Subject must not exceed 100 characters")]
        public string Subject { get; set; }

        [Required(ErrorMessage = "Please enter your message")]
        [StringLength(1000, ErrorMessage = "Message must not exceed 1000 characters")]
        public string Message { get; set; }
    }
}
